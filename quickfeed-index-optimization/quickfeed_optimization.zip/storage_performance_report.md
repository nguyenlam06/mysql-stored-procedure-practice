# B�O C�O ��NH GI� T�I NGUY�N V� HI?U NANG H? TH?NG QUICKFEED

## 1. Ph�n T�ch Nguy�n Nh�n S? C?
- **Ghi ch?m (Timeout):** M?i l?n INSERT, MySQL ph?i c?p nh?t d?ng th?i 5 c�y B-Tree, g�y ngh?n I/O dia.
- **Ph�nh to ? c?ng:** Index idx_content tr�n c?t TEXT t?n dung lu?ng l?n; c�c Index idx_post_type v� idx_is_visible c� Cardinality r?t th?p g�y l�ng ph� b? nh?.

## 2. Quy?t �?nh T?i Uu Index
- **Gi? l?i:** PRIMARY, idx_user_id, idx_created_at (C?n thi?t cho truy v?n l?c v� s?p x?p).
- **X�a b?:** 
  - idx_content: T?n dung lu?ng, thay th? b?ng FULLTEXT Index n?u c?n.
  - idx_post_type: Low Cardinality (ch? 3 gi� tr?).
  - idx_is_visible: Very Low Cardinality (ch? 2 gi� tr? 0/1).

## 3. Tr? L?i V?n ��p
- **T?ng v?t l� khi INSERT 5 Index:** Engine ph?i c?p nh?t 5 c�y B-Tree, g�y tranh ch?p ghi dia v� t�ch trang (Page Split), l�m k�o d�i th?i gian ph?n h?i.
- **Cardinality l� g�:** L� d? ph�n bi?t c?a d? li?u. C?t �t gi� tr? duy nh?t khi?n Query Optimizer uu ti�n qu�t to�n b?ng (Full Table Scan) thay v� d�ng B-Tree Index.
