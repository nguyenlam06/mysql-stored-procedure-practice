# NH?T K� TRA C?U V� TUONG T�C AI

## Prompt 1: Truy v?n dung lu?ng trong MySQL
- **Prompt:** "L�m c�ch n�o truy v?n information_schema.TABLES l?y Data Length v� Index Length t�nh theo MB?"
- **K?t qu?:** D�ng ph�p chia data_length / (1024 * 1024) v� index_length / (1024 * 1024).

## Prompt 2: Cardinality v� t�c h?i Over-Indexing
- **Prompt:** "T?i sao t?o Index B-Tree cho c?t BOOLEAN v� TEXT l?i g�y h?i d?n RAM v� Disk Space?"
- **K?t qu?:** C?t TEXT l�m ph�nh to B-Tree Node; c?t BOOLEAN c� Cardinality th?p khi?n Index v� d?ng nhung v?n t?n chi ph� c?p nh?t khi INSERT.
